package com.cg.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cg.spring.bean.ShippingDetails;
import com.cg.spring.service.ICustomerService;

@RestController
public class PlpController {

	@Autowired
	ICustomerService service;
	
	/*@RequestMapping(method=RequestMethod.POST, value="/show")
	public void showAll(ShippingDetails details) {
	
		
		service.showAll1(details);
	}*/
	@RequestMapping( value="/show1")
	public List<ShippingDetails> show1(ShippingDetails details) {
		
		service.addDetails(details);
		return service.showAll(details);
	}
	
	/*@RequestMapping(value = "/show1")
	public int addDetails(ShippingDetails details) {
		return service.addDetails(details);
	
	}*/
	@RequestMapping("/show")
	public List<ShippingDetails> showAll(ShippingDetails details) {
		return service.showAll(details);
		
	}
	
}
