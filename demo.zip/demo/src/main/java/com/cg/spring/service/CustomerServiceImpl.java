package com.cg.spring.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.bean.ShippingDetails;
import com.cg.spring.repo.ICustomerRepo;

@Service
public class CustomerServiceImpl implements ICustomerService{

	@Autowired
	ICustomerRepo repo;
	@Override
	public List<ShippingDetails> showAll(ShippingDetails details) {
		repo.save(details);
		List<ShippingDetails> list = new ArrayList<>();
		repo.findAll().forEach(list::add);
		return list;
		
	
	}
	/*@Override
	public void addDetails(ShippingDetails details) {
		
		repo.save(details);
	    //showAll();
		
		
	}
	@Override
	public void showAll1(ShippingDetails details) {
		// TODO Auto-generated method stub
		repo.save(details);
		
	}*/
	@Override
	public int addDetails(ShippingDetails s) {
		repo.save(s);
		return 0;
	}
	
}
