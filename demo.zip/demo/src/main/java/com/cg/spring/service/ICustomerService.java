package com.cg.spring.service;

import java.util.List;


import com.cg.spring.bean.ShippingDetails;

public interface ICustomerService {

	public List<ShippingDetails> showAll(ShippingDetails details);
    /*public  void addDetails(ShippingDetails details );
    public void showAll1(ShippingDetails details);*/
	public int addDetails(ShippingDetails s);
	//List<ShippingDetails> showAll();
	
	
}
